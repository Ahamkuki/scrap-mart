# ScrapMart Production

A mobile-first scrap marketplace built for real deployment.

## Included
- Customer registration/login
- Product catalogue, categories and search
- Order data model and customer order history
- Sell-your-scrap requests
- WhatsApp deep links
- Admin dashboard
- Admin product/order/sell-request management
- PostgreSQL via Prisma
- SEO metadata, sitemap and robots
- No secrets hardcoded

## Before production
1. Install Node.js 20+.
2. Create a PostgreSQL database (Supabase, Neon or another PostgreSQL provider).
3. Copy `.env.example` to `.env` and set every value.
4. Run `npm install`
5. Run `npm run db:push`
6. Run `npm run db:seed`
7. Run `npm run build`
8. Run `npm start`

## Security
Use a long random `AUTH_SECRET` and a strong unique admin password. Set HTTPS at your hosting provider. Never commit `.env`.

## WhatsApp
Set `WHATSAPP_NUMBER` to the business WhatsApp number in international format without `+` or spaces, e.g. `9198XXXXXXXX`.

## Admin 2FA
The database has 2FA fields and the architecture is prepared for TOTP. The production deployment should enable the authenticator enrollment/verification screen before exposing admin operations. Do not treat an empty 2FA secret as enabled.

## Payments
No payment gateway is included because the requested business flow is WhatsApp/contact-first. Payment can remain offline/on-contact.
