import { db } from "@/lib/db";
import { whatsappUrl } from "@/lib/whatsapp";
import Link from "next/link";
export default async function Product({params}:{params:Promise<{slug:string}>}){
 const p=await db.product.findUnique({where:{slug:(await params).slug},include:{category:true}});
 if(!p)return <main className="section"><div className="container"><h1>Product not found</h1></div></main>;
 const wa=whatsappUrl(`Hello ScrapMart, I want to buy ${p.name}. Please share current price and availability.`);
 return <main className="section"><div className="container"><Link href="/products">← All products</Link><div className="card" style={{marginTop:18}}><div className="product-image">♻️</div><h1>{p.name}</h1><div className="pill">{p.category.name}</div><p>{p.description}</p><div className="price">₹{Number(p.price).toLocaleString("en-IN")} / {p.unit}</div><p className="muted">Listed price is indicative. Confirm current rate, grade and quantity with us.</p><div className="actions"><a className="btn whatsapp" href={wa}>WhatsApp About This Scrap</a><Link className="btn primary" href="/login">Login to Place Order</Link></div></div></div></main>;
}