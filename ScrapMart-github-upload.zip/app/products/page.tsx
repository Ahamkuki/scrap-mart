import Link from "next/link";
import { db } from "@/lib/db";

export default async function Products({searchParams}:{searchParams:Promise<{q?:string;category?:string}>}){
  const sp=await searchParams; const q=sp.q||"";
  const products=await db.product.findMany({where:{active:true, ...(q?{OR:[{name:{contains:q,mode:"insensitive"}},{description:{contains:q,mode:"insensitive"}}]}:{})},include:{category:true},orderBy:{name:"asc"}});
  return <main className="section"><div className="container"><h1>Scrap Products</h1><form className="actions"><input name="q" defaultValue={q} placeholder="Search scrap..." style={{padding:12,borderRadius:9,border:"1px solid #ccd8d1",flex:1}}/><button className="btn primary">Search</button></form><div className="grid" style={{marginTop:22}}>{products.map(p=><Link className="card" href={`/products/${p.slug}`} key={p.id}><div className="product-image">♻️</div><h3>{p.name}</h3><p className="muted">{p.description}</p><div className="price">₹{Number(p.price).toLocaleString("en-IN")} / {p.unit}</div></Link>)}</div></div></main>;
}